<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link href=" <?php echo e(URL::asset('css/app.css')); ?>" rel="stylesheet">
  <link href=" https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css" rel="stylesheet">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>

  <title>Login</title>
</head>
<body style="background-image: url(<?php echo e(URL::asset('images/background.png')); ?>); background-repeat:no-repeat; background-size: cover ">
  <h1 class="text-white m-4">Admin Login</h1>
<div class="container">
  <div class="row">
    <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
      <div class="card card-signin my-5">
        <div class="card-body">
          <h5 class="card-title text-center">Log In</h5>
          
          <form class="log-in-form" action="login" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-label-group mt-2">
              <label for="login_email">Email address</label>
              <input type="text" id="login_email" name="login_email" class="form-control" placeholder="Email address" autofocus
              value=<?php echo e(old('login_email')); ?>>
              <?php $__errorArgs = ['login_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-danger error_text create_account_form_lastname_error"> <?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-label-group mt-2">
              <label for="login_password">Password</label>
              <input type="password" id="login_password" name="login_password" class="form-control" placeholder="Password" >
              <?php $__errorArgs = ['login_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-danger error_text create_account_form_lastname_error"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class="btn btn-lg btn-primary btn-block text-uppercase mt-3" id="loginBtn" type="submit">Log in</button>
          </form>
          
          <br><a href="/barangay/login">Go to client login ></a>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\barangay-main\resources\views/pages/AdminPanel/user/login.blade.php ENDPATH**/ ?>