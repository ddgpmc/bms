<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link href=" <?php echo e(URL::asset('css/app.css')); ?>" rel="stylesheet">
  <link href=" https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css" rel="stylesheet">

  <link rel="stylesheet" href=<?php echo e(URL::asset('css/ClientCSS/Footer-Clean.css')); ?>>
  <link rel="stylesheet" href=<?php echo e(URL::asset('css/ClientCSS/Header-Blue.css')); ?>>
  <link rel="stylesheet" href=<?php echo e(URL::asset('css/ClientCSS/styles.css')); ?>>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>

  <script>
    
  </script>

  <title>Login</title>
</head>
<body style="background-image: url(<?php echo e(URL::asset('images/city.jpg')); ?>); background-repeat:no-repeat; background-size: cover ">

<?php echo $__env->make('inc.client_nav_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5">
  <div class="row justify-content-center" >
    <div class="col-sm-9 col-md-7 col-lg-7">
      <div class="card card-signin my-5">
        <div class="card-body">
          <?php if(session()->has("success_register")): ?>
          <div class="alert alert-success">
            <?php echo e(session()->get("success_register")); ?>

          </div>
          <?php endif; ?>
          <h5 class="card-title text-center">Log In</h5>
          
          <form class="log-in-form" action="/barangay/login" method="post"> 
            <?php echo csrf_field(); ?>
            <div class="form-label-group mt-2">
              <label for="client_login_email">Email address</label>
              <input type="text" id="client_login_email" name="client_login_email" class="form-control" placeholder="Email address" autofocus
              value=<?php echo e(old('client_login_email')); ?>>
              <?php $__errorArgs = ['client_login_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-danger error_text create_account_form_lastname_error"> <?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-label-group mt-2">
              <label for="client_login_password">Password</label>
              <input type="password" id="client_login_password" name="client_login_password" class="form-control" placeholder="Password" >
              <?php $__errorArgs = ['client_login_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="text-danger error_text create_account_form_lastname_error"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <br><a href="/barangay/forgot_password">Forgot your password?</a>
            </div>

            <button class="btn btn-lg btn-success btn-block text-uppercase mt-3" id="clientLoginBtn" type="submit">Log in</button>
          </form>
          


          <br><a href="/barangay/register">Don't have an account?? Register!</a>
          <br><a href="/login">Go to admin login</a>
        </div>
      </div>
      <br><br><br><br>
    </div>
  </div>
</div>


</body>
</html>
<?php /**PATH C:\Users\Adones\Downloads\barangay-main\resources\views/pages/ClientSide/userlogin/login.blade.php ENDPATH**/ ?>