<h1>Profile Page</h1>
<h2>{{ Session('user.email')}}</h2>
<h2>{{ Session('user.password')}}</h2>

<a href="logout">Log out</a>