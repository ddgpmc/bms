<?php

namespace Database\Factories;

use App\Models\Certificate_list;
use Illuminate\Database\Eloquent\Factories\Factory;

class CertificateListFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Certificate_list::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
