<?php

namespace Database\Factories;

use App\Models\brgy_official;
use Illuminate\Database\Eloquent\Factories\Factory;

class BrgyOfficialFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = brgy_official::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
