<header class="header-blue" style="padding-bottom: 0px;">
    <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
        <div class="container-fluid"><a class="navbar-brand" href="#" style="font-size: 45px;font-family: bodoni mt;"><img src="<?php echo e(URL::asset('images/logos.png')); ?>" style="resize: both;width: 100px;margin-right: 30px;"><p class="navbar-brand" id="client_header_login" style="font-size: 45px;"><?php echo e($image->barangay_name ?? 'Brgy. Tan-awan Management System'); ?></p></a>
        </div>
    </nav>
</header>
<?php /**PATH C:\Users\Adones\Downloads\barangay-main\resources\views/inc/client_nav_login.blade.php ENDPATH**/ ?>