<!DOCTYPE html>
<html lang="en" style="position: relative;min-height: 100%;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

    <link rel="stylesheet" href=<?php echo e(URL::asset('css/ClientCSS/Footer-Clean.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(URL::asset('css/ClientCSS/Header-Blue.css')); ?>>
    <link rel="stylesheet" href=<?php echo e(URL::asset('css/ClientCSS/styles.css')); ?>>

</head>

<body style="margin: 0 0 169px;">
    <input type="hidden" id = "current_resident" data-id = <?php echo e(session("resident.id")); ?>>
    
    <?php echo $__env->make('inc.client_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="margin-top: 20px;align-items: center;margin-bottom: 70px;">
        <div class="row" style="align-items: center;">
            <div class="col-md-6">
                <div class="carousel slide" data-ride="carousel" id="carousel-1" style="background-size: cover;">
                    <div class="carousel-inner">
                        <div class="carousel-item active"><img class="w-100 d-block" src="<?php echo e(URL::to('images/city.jpg')); ?>" alt="Slide Image"></div>
                        <div class="carousel-item"><img class="w-100 d-block" src="<?php echo e(URL::to('images/city1.png')); ?>" alt="Slide Image"></div>
                        <div class="carousel-item"><img class="w-100 d-block" src="<?php echo e(URL::to('images/city2.png')); ?>" alt="Slide Image"></div>
                    </div>
                    <div><a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev"><span class="carousel-control-prev-icon"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next" href="#carousel-1" role="button" data-slide="next"><span class="carousel-control-next-icon"></span><span class="sr-only">Next</span></a></div>
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-1" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-1" data-slide-to="1"></li>
                        <li data-target="#carousel-1" data-slide-to="2"></li>
                    </ol>
                </div>
            </div>
            <div class="col-md-6">
                <p><br><strong>VISION</strong></br>
MITACOR aspires for a quality life for everyone influenced by innovative technologies and technological advancement.</p>
<p><br><strong>MISSION</strong></br>

MITACOR’s mission is plain and simple: to provide and promote quality technology through practical ICT solutions for all walks of life. We aim to uplift the lives of many by bringing them touchpoints and connections that will change and empower the way they live. Our existence is to make everyone’s communication faster, their information access better, and the range of opportunities even wider. We make things closer at the point of your finger.</p>
            </div>
        </div>
    </div>
    <br><br>
    <footer class="footer-clean" style="background-color: #051c2c;position: absolute;left: 0;bottom: 0;height: 174px;width: 100%;overflow: hidden;margin-top: 30px; color: #54c0e8 !important;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-4 col-md-3 item">
                    <h3>Services</h3>
                    <ul>
                        <li><a href="#">Web design</a></li>
                        <li><a href="#">Development</a></li>
                        <li><a href="#">Hosting</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-3 item">
                    <h3>About</h3>
                    <ul>
                        <li><a href="#">Company</a></li>
                        <li><a href="#">Team</a></li>
                        <li><a href="#">Legacy</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-md-3 item">
                    <h3>Careers</h3>
                    <ul>
                        <li><a href="#">Job openings</a></li>
                        <li><a href="#">Employee success</a></li>
                        <li><a href="#">Benefits</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a>
                    <p class="copyright">Maharlican Innovations and Technology Applications Corporation © 2022</p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\barangay-main\resources\views/pages/ClientSide/userdashboard/homepage.blade.php ENDPATH**/ ?>